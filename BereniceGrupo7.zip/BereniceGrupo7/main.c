#include "berenice.h"

int main()
{
    int opc;
    int loop = 0; // Declara��o da vari�vel 'loop' que ser� utilizada como condi��o de parada do la�o

    while (!loop)
    {
        opc = menu_principal(); // Chamada da fun��o 'menu_principal()' para exibir o menu principal e obter a op��o escolhida

        switch (opc)
        {
        case 1:
            menu_produto(); // Chamada da fun��o 'menu_produto()' para exibir o menu de produtos
            break; // Encerra o switch

        case 2:
            menu_venda(); // Chamada da fun��o 'menu_venda()' para exibir o menu de vendas
            break; // Encerra o switch

        case 3:
            relatorio(); // Chamada da fun��o 'relatorio()' para exibir o relat�rio

            printf("\n Saindo... \n"); // Exibe a mensagem "Saindo..."
            loop = 1; // Define o valor 1 para 'loop' para sair do la�o
            break; // Encerra o switch

        case 999:
            lerBackup(); // Chamada da fun��o que le o arquivo backup que e produtos2.bin
            break; // Encerra o switch

        case 888:
            salvarCSV(); // Chamada da fun��o 'salvarCSV()' para salvar os dados em um arquivo CSV
            break; // Encerra o switch

        case 777:
            atualizarVendas(); // Chamada da fun��o 'atualizarVendas()' para atualizar as vendas
            break; // Encerra o switch

        default: // Se a op��o escolhida n�o corresponder a nenhum dos casos anteriores
            printf("\n\t Opcao invalida!\n"); // Exibe a mensagem "Op��o inv�lida!"
            break; // Encerra o switch
        }
    }
    return 0;

}
