#ifndef BERENICE_H_INCLUDED
#define BERENICE_H_INCLUDED

typedef struct produtos produtos;

///MENUS
int menu_principal();
void menu_produto();
void menu_venda();

///FUNCOES DO MENU PRODUTO
void exibir();
void cadastrar();
void atualizar();
void excluir();

///OPCOES DE ARQUIVO
void salvar(); ///Salva o arquivo binario
void ler(); ///Le o arquivo binario
void salvarRelatorioTXT(); /// Salva o relatorio em Txt de forma silenciosa

///FUNCOES DE VENDA
void venda(); /// Menu de venda
///CUPOM FISCAL
void bbSort(produtos *prtVendidos, int numItens); ///Bbsort para colocar do maior subtotal para o menor no cupom
void duplicados(produtos *prtVendidos, int numItens, float total); ///Controle dos itens duplicados no cupom
void cupomFiscal(produtos *prtVendidos, int numItens, float total); /// Recebimento dos itens vendidos e exibicao do cupom
///PAGAMENTO
void menu_pagamento(float total); /// Menu de escolha do tipo de pagamento
void avista(float *total); /// Opcao de venda a vista e seus descontos
void aprazo(float *total); /// Opcao de venda a prazo e seus acrescimos
///RELATORIO
void relatorio(); /// Exibe o relatorio com itens vendidos, caso tenha 0 vendas, o item fica oculto

///GAMBIARRAS
void atualizarVendas(); /// Apenas para manipula��o dos itens vendidos
void lerBackup(); /// L� os itens salvos caso o primeiro d� erro
void salvarTXT(); ///Salva a lista de produtos em TXT de forma silenciosa
void salvarCSV();   ///Salva arquivo exportavel para excel

#endif // BERENICE_H_INCLUDED
