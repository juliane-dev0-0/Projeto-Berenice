#include "berenice.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct produtos{
    int codigo;
    char nome[25];
    float valor;
    int quantidade;

    int qtdVendida;
    float valorVendido;
};

produtos *estoque = NULL;

int indiceG = 0;

int menu_principal(){
    int opc = 0;

    ler();

    printf("\n\tMenu Principal\n");

    printf("\n 1 - Produtos");
    printf("\n 2 - Vendas");
    printf("\n 3 - Sair");
    printf("\n");

    printf("\n Escolha uma opcao: ");
    scanf("%d", &opc);
    getchar();

    return opc;
}

void menu_produto(){
    int opc = 0; // Declara��o da vari�vel 'opc' que ser� utilizada para armazenar a op��o escolhida pelo usu�rio
    int erro_menu_produto = 0; // Declara��o da vari�vel 'erro_menu_produto' que ser� utilizada como condi��o de parada do loop

    ler(); // Chamada da fun��o 'ler()' para ler os dados

    exibir(); // Chamada da fun��o 'exibir()' para exibir os dados

    do
    {
        printf("\n\tOpcoes: Produtos\n");

        printf("\n 1 - Exibir"); // Op��o para exibir os produtos
        printf("\n 2 - Cadastrar"); // Op��o para cadastrar um novo produto
        printf("\n 3 - Atualizar"); // Op��o para atualizar um produto existente
        printf("\n 4 - Excluir"); // Op��o para excluir um produto
        printf("\n 5 - Salvar"); // Op��o para salvar os dados
        printf("\n 6 - Ler"); // Op��o para ler os dados novamente
        printf("\n 7 - Voltar"); // Op��o para voltar ao menu principal
        printf("\n");

        printf("\n Escolha uma opcao: ");
        scanf("%d", &opc); // L� a op��o escolhida pelo usu�rio
        getchar();

        switch (opc)
        {
        case 1:
            exibir();
            break; // Encerra o switch

        case 2:
            cadastrar();
            break; // Encerra o switch

        case 3:
            atualizar(); // Chamada da fun��o 'atualizar()' para atualizar um produto existente
            break; // Encerra o switch

        case 4:
            excluir();
            break; // Encerra o switch

        case 5:
            salvar(); // Chamada da fun��o 'salvar()' para salvar os dados
            break; // Encerra o switch

        case 6:
            ler(); // Chamada da fun��o 'ler()' para ler os dados novamente
            break; // Encerra o switch

        case 7:
            return; // Retorna da fun��o para voltar ao menu principal
            break; // Encerra o switch

        default: // Se a op��o escolhida n�o corresponder a nenhum dos casos anteriores
            printf("\n\tOpcao invalida!\n");
            erro_menu_produto = 1; // Define o valor 1 para 'erro_menu_produto' para continuar no loop
            break; // Encerra o switch
        }
    } while (erro_menu_produto); // Repete o loop enquanto 'erro_menu_produto' for verdadeiro
}


void menu_venda(){
    int opc = 0; // Declara��o da vari�vel 'opc' que ser� utilizada para armazenar a op��o escolhida pelo usu�rio
    int erro_menu_venda = 0; // Declara��o da vari�vel 'erro_menu_venda' que ser� utilizada como condi��o de parada do loop

    ler(); // Chamada da fun��o 'ler()' para ler os dados

    do
    {
        printf("\n\tOpcoes: Vendas\n");

        printf("\n 1 - Realizar venda");
        printf("\n 2 - Relatorio de vendas");
        printf("\n 3 - Voltar");
        printf("\n");

        printf("\n Escolha uma opcao: ");
        scanf("%d", &opc); // L� a op��o escolhida pelo usu�rio
        getchar();

        switch (opc)
        {
        case 1:
            venda(); // Chamada da fun��o 'venda()' para realizar uma venda
            break; // Encerra o switch

        case 2:
            relatorio(); // Chamada da fun��o 'relatorio()' para exibir o relat�rio de vendas
            break; // Encerra o switch

        case 3:
            return; // Retorna da fun��o para voltar ao menu principal
            break; // Encerra o switch

        default: // Se a op��o escolhida n�o corresponder a nenhum dos casos anteriores
            printf("\n\tOpcao invalida!\n");
            erro_menu_venda = 1; // Define o valor 1 para 'erro_menu_venda' para continuar no loop
            break; // Encerra o switch
        }

    } while (erro_menu_venda); // Repete o loop enquanto 'erro_menu_venda' for verdadeiro

}

void exibir(){

    if (estoque == NULL || indiceG == 0)
    {
        printf("\n Nenhum Produto no estoque \n");
    }

    // Exibe cabe�alho da tabela de produtos
    printf("\n +------------------------------------------------------------+\n");
    printf(" | Codigo | Nome do Item              | Valor Unit. | Estoque |\n");

    // Itera sobre o estoque e exibe cada produto
    for (int i = 0; i < indiceG; i++)
    {
        // Exibe informa��es de cada produto na tabela
        printf(" +------------------------------------------------------------+\n");
        printf(" |   %-3d  | %-25s |   R$ %-6.2f |   %-3d   |\n", estoque[i].codigo, estoque[i].nome, estoque[i].valor, estoque[i].quantidade);
    }

    // Exibe linha final da tabela
    printf(" +------------------------------------------------------------+\n");
}

void cadastrar()
{
    int i;

    printf("\n\t\tInsira as informacoes para o novo cadastro:\n");

    produtos novo_produto;

    // VERIFICA CODIGO
    do{
        printf("\n Informe o codigo: ");
        scanf("%d", &(novo_produto.codigo));
        getchar();

        if ((novo_produto.codigo) <= 0) {
            printf("\n\t Erro: Codigo invalido!\n");
        }
        else{
            for (i = 0; i < indiceG; i++) {
                if ((novo_produto.codigo) == estoque[i].codigo) {
                    printf("\n\t Erro: Esse codigo ja esta em uso!\n");
                    (novo_produto.codigo) = 0;
                }
            }
        }
    } while ((novo_produto.codigo) <= 0);

    // VERIFICA NOME
    do{

        fflush(stdin); // Limpa o buffer de entrada

        printf("\n Informe o nome: ");
        scanf(" %[^\n]s", novo_produto.nome); // L� uma string com espa�os em branco

        getchar();
            // strlen verifica o tamanho da string para nao exceder os 25 caracteres
        if(strlen(novo_produto.nome) > 25){
            printf("\n\t Erro: Esse nome excede o limite de 25 caracteres!\n");
        }
        else {
            for (i = 0; i < indiceG; i++) {    // Compara os nomes, se o retorno for 0 eles sao iguais
                if (strcmp(novo_produto.nome, estoque[i].nome) == 0) {
                    printf("\n\t Erro: Esse nome ja esta em uso!\n");
                    break;
                }
            }
        }
    } while (strlen(novo_produto.nome) > 25 || i < indiceG);

    //VERIFICA VALOR
    do {
        printf("\n Informe o valor:  R$ ");
        scanf("%f", &(novo_produto.valor));
        getchar();

        if((novo_produto.valor) <= 0){
            printf("\n\t Erro: Valor nao pode ser negativo!\n");
        }
    }while((novo_produto.valor) <= 0);

    //VERIFICA QUANTIDADE
    do {
        printf("\n Informe a quantidade em estoque: ");
        scanf("%d", &(novo_produto.quantidade));
        getchar();

        if((novo_produto.quantidade) < 0){
            printf("\n\t Erro: Quantidade nao pode ser negativa!\n");
        }
    }while((novo_produto.quantidade) < 0);

    novo_produto.qtdVendida = 0;     //Iniciando em zero para nao obter lixo de memoria
    novo_produto.valorVendido = 0;

    estoque = (produtos *)realloc(estoque, (indiceG + 1) * sizeof(produtos)); //Realocando espa�o para o novo registro

    estoque[indiceG++] = novo_produto; //agora sim passa os dados para a struct

    menu_produto(); //retorna as opcoes de produtos
}

void atualizar()
{
    // Verifica se n�o h� produtos cadastrados
    if (estoque == NULL || indiceG == 0)
    {
        printf("\n Nenhum produto cadastrado.\n");
        return;
    }

    int codigo;
    printf("\n Informe o codigo do produto a ser atualizado: ");
    scanf("%d", &codigo);

    int encontrado = 0;
    for (int i = 0; i < indiceG; i++)
    {
        // Verifica se o c�digo do produto � igual ao informado
        if (estoque[i].codigo == codigo)
        {
            encontrado = 1;

             // Verifica o novo nome do produto
            do{
                printf("\n Informe o novo nome: ");
                scanf(" %[^\n]s", estoque[i].nome);
                getchar();

                // Verifica se o nome excede o limite de 25 caracteres
                if(strlen(estoque[i].nome) > 25){
                    printf("\n\t Erro: Esse nome excede o limite de 20 caracteres!\n");
                }
            } while (strlen(estoque[i].nome) > 25);

            // Verifica o novo valor do produto
            do {
                printf("\n Informe o novo valor: R$ ");
                scanf("%f", &(estoque[i].valor));
                getchar();

                // Verifica se o valor � negativo
                if((estoque[i].valor) <= 0){
                    printf("\n\t Erro: Valor nao pode ser negativo!\n");
                }
            }while((estoque[i].valor) <= 0);

            // Verifica a nova quantidade do produto
            do {
                 printf("\n Informe a nova quantidade em estoque: ");
            scanf("%d", &(estoque[i].quantidade));
            getchar();

                    // Verifica se a quantidade � negativa
                    if((estoque[i].quantidade) < 0){
                        printf("\n\t Erro: Quantidade nao pode ser negativa!\n");
                    }
            }while((estoque[i].quantidade) < 0);

            printf("\n\tProduto atualizado com sucesso.\n");

            menu_produto();
            break;
        }
    }

    // Se o produto n�o foi encontrado
    if (!encontrado)
    {
        printf("\n\tProduto nao encontrado.\n");
    }
}

void atualizarVendas()
{
    int quantidade = 0;

    if (estoque == NULL || indiceG == 0)
    {
        printf("\n Nenhum produto cadastrado.\n");
        return;
    }

    printf("\n -- Atualizar Qtd. Vendida -- \n");

    int codigo;
    printf("\n Informe o codigo: ");
    scanf("%d", &codigo);
    getchar();

    int encontrado = 0;
    for (int i = 0; i < indiceG; i++)
    {
        if (estoque[i].codigo == codigo)
        {
            encontrado = 1;

            printf("\n Item: %s", estoque[i].nome);
            printf("\n Valor unit: R$ %.2f", estoque[i].valor);
            printf("\n Estoque: %d \n", estoque[i].quantidade);

            printf("\n Qt. Vendida: %d", estoque[i].qtdVendida);
            printf("\n Valor Vendido: R$ %.2f \n", estoque[i].valorVendido);

            do{
            printf("\n Digite a Qt. Vendida: ");
            scanf("%d",&quantidade);
            getchar();

            if(quantidade > estoque[i].quantidade){
                printf("\n\t Quantidade insuficiente!\n");

            }

        }while(quantidade > estoque[i].quantidade);


            estoque[i].qtdVendida += quantidade;

            estoque[i].quantidade -= quantidade;

            estoque[i].valorVendido = estoque[i].valor * estoque[i].qtdVendida;

            printf("\n Atualizado com sucesso. \n");

            printf("\n Item: %s", estoque[i].nome);
            printf("\n Valor unit: R$ %.2f", estoque[i].valor);
            printf("\n Estoque: %d \n", estoque[i].quantidade);

            printf("\n Qt. Vendida: %d", estoque[i].qtdVendida);
            printf("\n Valor Vendido: R$ %.2f \n", estoque[i].valorVendido);

            break;
        }
    }
    if (!encontrado)
    {
            printf("\n\tProduto nao encontrado.\n");
    }
}

void excluir()
{
    // Verifica se n�o h� produtos cadastrados
    if (estoque == NULL || indiceG == 0)
    {
        printf("\n Nenhum produto cadastrado.\n");
        return;
    }

    int codigo;
    printf("\n Informe o codigo do produto a ser excluido: ");
    scanf("%d", &codigo);
    getchar();

    int encontrado = 0;
    for (int i = 0; i < indiceG; i++)
    {
        // Verifica se o c�digo do produto � igual ao informado
        if (estoque[i].codigo == codigo)
        {
            encontrado = 1;

            char resposta;
            printf("\n Tem certeza que deseja excluir o item '%s'? (S/N): ",estoque[i].nome);
            scanf(" %c", &resposta);

            if (resposta == 's' || resposta == 'S')
            {
                // Loop aninhado para realocar os elementos do vetor ap�s a exclus�o
                for (int j = i; j < indiceG - 1; j++)
                {
                    estoque[j] = estoque[j + 1];
                }

                // Realoca o vetor de produtos com um tamanho menor
                estoque = (produtos *)realloc(estoque, (indiceG - 1) * sizeof(produtos));
                indiceG--;

                // Salva as altera��es
                salvar();

                menu_produto();
                break;
            }
            else
            {
                printf("\n\t Exclusao cancelada.\n");
                menu_produto();
            }
        }
    }

    // Se o produto n�o foi encontrado
    if (!encontrado)
    {
        printf("\n\tProduto nao encontrado.\n");
    }
}

void salvar()
{
    // Verifica se n�o h� produtos cadastrados
    if (estoque == NULL || indiceG == 0)
    {
        printf("\n Nenhum produto cadastrado.\n");
        return;
    }

    FILE *arquivo;

    // Abre o arquivo "produtos.bin" em modo de escrita bin�ria
    arquivo = fopen("produtos.bin", "wb");

    if (arquivo == NULL)
    {
        printf("\n Erro ao abrir o arquivo.\n");
        return;
    }

    // Escreve os dados da struct no arquivo
    fwrite(estoque, sizeof(produtos), indiceG, arquivo);

    // Fecha o arquivo
    fclose(arquivo);
}

void ler()
{
    FILE *arquivo;

     // Abre o arquivo "produtos.bin" em modo de leitura
    arquivo = fopen("produtos.bin", "rb");

    // Verifica se o arquivo n�o foi encontrado
    if (arquivo == NULL)
    {
        printf("\n\tNenhum arquivo encontrado.\n");
        return;
    }

    produtos novo_produto;

    // L� os dados do arquivo e adiciona ao vetor 'estoque'
    while (fread(&novo_produto, sizeof(produtos), 1, arquivo) == 1)
    {
        int cod_duplicado = 0;

        // Verifica se o c�digo do produto j� existe no vetor 'estoque'
        for (int i = 0; i < indiceG; i++)
        {
            if (estoque[i].codigo == novo_produto.codigo)
            {
                cod_duplicado = 1;
                break;
            }
        }

        // Se o c�digo n�o estiver duplicado, adiciona o produto ao vetor 'estoque'
        if (!cod_duplicado)
        {
            estoque = (produtos *)realloc(estoque, (indiceG + 1) * sizeof(produtos));
            estoque[indiceG++] = novo_produto;
        }
    }

    // Fecha o arquivo
    fclose(arquivo);

    salvar(); // Chama a fun��o 'salvar()' para salvar os dados atualizados em um arquivo

    salvarTXT(); // Chama a fun��opara realizar um salvamento em um arquivo de texto
}

void lerBackup(){
    FILE *arquivo;

     // Abre o arquivo "produtos.bin" em modo de leitura
    arquivo = fopen("produtos2.bin", "rb");

    // Verifica se o arquivo n�o foi encontrado
    if (arquivo == NULL)
    {
        printf("\n\tNao existe um backup chamado produtos2.bin\n");
        return;
    }
    produtos novo_produto;

    // L� os dados do arquivo e adiciona ao vetor 'estoque'
    while (fread(&novo_produto, sizeof(produtos), 1, arquivo) == 1)
    {
        int cod_duplicado = 0;

        // Verifica se o c�digo do produto j� existe no vetor 'estoque'
        for (int i = 0; i < indiceG; i++)
        {
            if (estoque[i].codigo == novo_produto.codigo)
            {
                cod_duplicado = 1;
                break;
            }
        }

        // Se o c�digo n�o estiver duplicado, adiciona o produto ao vetor 'estoque'
        if (!cod_duplicado)
        {
            estoque = (produtos *)realloc(estoque, (indiceG + 1) * sizeof(produtos));
            estoque[indiceG++] = novo_produto;
        }
    }

    // Fecha o arquivo
    fclose(arquivo);

    printf("\n\tArquivo backup 'produtos2.bin' lido com sucesso! \n ");
}

void salvarTXT()
{
    FILE *arquivo;
    arquivo = fopen("produtos.txt", "w");

     // Exibe cabe�alho da tabela de produtos
    fprintf(arquivo, "\n +------------------------------------------------------------+\n");
    fprintf(arquivo, " | Codigo | Nome do Item              | Valor Unit. | Estoque |\n");

    // Itera sobre o estoque e exibe cada produto
    for (int i = 0; i < indiceG; i++)
    {
        // Exibe informa��es de cada produto na tabela
        fprintf(arquivo, " +------------------------------------------------------------+\n");
        fprintf(arquivo, " |   %-3d  | %-25s |   R$ %-6.2f |   %-3d   |\n", estoque[i].codigo, estoque[i].nome, estoque[i].valor, estoque[i].quantidade);
    }

    // Exibe linha final da tabela
    fprintf(arquivo, " +------------------------------------------------------------+\n");

    fclose(arquivo);
}

void salvarCSV() {
    FILE *arquivo;

    arquivo = fopen("produtos.csv", "w");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    fprintf(arquivo, "Codigo\tNome do Item\tValor Unit.\tEstoque\tQtd. Vendida\tValor Vendido\n");
    for (int i = 0; i < indiceG; i++) {
        char valorUnitario[15];
        char valorTotalVendido[15];
        snprintf(valorUnitario, sizeof(valorUnitario), "%.2f", estoque[i].valor);
        snprintf(valorTotalVendido, sizeof(valorTotalVendido), "%.2f", estoque[i].valorVendido);
        for (int j = 0; valorUnitario[j] != '\0'; j++) {
            if (valorUnitario[j] == '.') {
                valorUnitario[j] = ',';
            }
        }
        for (int j = 0; valorTotalVendido[j] != '\0'; j++) {
            if (valorTotalVendido[j] == '.') {
                valorTotalVendido[j] = ',';
            }
        }

        fprintf(arquivo, "%d\t%s\t%s\t%d\t%d\t%s\n", estoque[i].codigo, estoque[i].nome, valorUnitario, estoque[i].quantidade, estoque[i].qtdVendida, valorTotalVendido);
    }

    fclose(arquivo);

    printf("\n Arquivo CSV salvo com sucesso \n");
}

void venda() {
    int codigo, quantidade;
    char continuar = 's';
    float total = 0.0, subtotal = 0.0;

    // Ponteiro para armazenar os produtos vendidos
    produtos *ptrVendidos = NULL;

    // Vari�vel para acompanhar o n�mero de itens vendidos
    int numItens = 0;

    // Exibe a lista de produtos dispon�veis
    exibir();

    // Loop para realizar as vendas
    do {
        printf("\n Informe o codigo do item: ");
        scanf("%d", &codigo);
        getchar();

        int encontrado = 0;

        // Verifica se o c�digo do produto existe no estoque
        for (int i = 0; i < indiceG; i++) {
            if (estoque[i].codigo == codigo) {
                encontrado = 1;

                printf("\n Nome do item: %s", estoque[i].nome);
                printf("\n Valor unitario: R$ %.2f\n", estoque[i].valor);

                printf("\n Informe a quantidade: ");
                scanf("%d", &quantidade);
                getchar();

                // Verifica se h� quantidade suficiente em estoque
                if (estoque[i].quantidade >= quantidade) {

                    //diminui a quantidade em estoque
                    estoque[i].quantidade -= quantidade;

                    //calcula o subtotal baseado no valor unitario * quantidade
                    subtotal = quantidade * estoque[i].valor;

                    //soma o subtotal de tudo e passa para o total
                    total += subtotal;

                    // Atualiza informa��es de venda no estoque
                    estoque[i].qtdVendida += quantidade;
                    estoque[i].valorVendido += subtotal;

                    // Adiciona o item vendido ao vetor de produtos vendidos
                    numItens++;
                    ptrVendidos = (produtos *)realloc(ptrVendidos, (numItens+1)*sizeof(produtos));
                    ptrVendidos[numItens-1] = estoque[i];
                    ptrVendidos[numItens-1].quantidade = quantidade;
                    ptrVendidos[numItens-1].valorVendido = subtotal;

                    printf("\n\t Subtotal: R$ %.2f\n", subtotal);

                } else {
                    printf("\n\tQuantidade em estoque insuficiente.\n");
                    encontrado = 0;
                    break;
                }
            }
        }

        // Resposta caso o produto nao tenha sido encontrado
        if (!encontrado) {
            printf("\n\tEscolha um produto disponivel.\n");
            continue;
        }

        printf("\n Deseja adicionar mais itens? (S/N): ");
        scanf(" %c", &continuar);
        getchar();

    } while (continuar == 's' || continuar == 'S');

    printf("\n\t Total: R$ %.2f\n", total);

    // Chama a fun��o para imprimir o cupom fiscal
    cupomFiscal(ptrVendidos, numItens, total);

    // Chama a fun��o para selecionar o m�todo de pagamento
    menu_pagamento(total);

    // Libera a mem�ria alocada para o vetor de produtos vendidos
    free(ptrVendidos);

    // Salva as altera��es na struct no arquivo
    salvar();
}

void bbSort(produtos *ptrVendidos, int numItens){
    produtos aux;

    // Bubble sort para ordenar os produtos vendidos pelo valor vendido em ordem decrescente
    for (int i = 0; i < numItens - 1; i++){
        for (int j = 0; j < numItens - i - 1; j++){
            if (ptrVendidos[j].valorVendido < ptrVendidos[j+1].valorVendido){
                aux = ptrVendidos[j];
                ptrVendidos[j] = ptrVendidos[j+1];
                ptrVendidos[j+1] = aux;
            }
        }
    }
}

void duplicados(produtos *ptrVendidos, int numItens, float total) {
    float subtot;

    // Percorre os produtos vendidos para verificar duplicatas
    for (int j = 0; j < numItens; j++) {
        for (int i = j + 1; i < numItens; i++) {
            if (ptrVendidos[j].codigo == ptrVendidos[i].codigo) {
                ptrVendidos[j].quantidade += ptrVendidos[i].quantidade;
                subtot = ptrVendidos[i].valor * ptrVendidos[i].quantidade;
                ptrVendidos[j].valorVendido += subtot;
                ptrVendidos[i].quantidade = 0;
            }
        }
    }
}

void cupomFiscal(produtos *ptrVendidos, int numItens, float total) {
    total = 0.0;

    // Remove duplicatas e atualiza os valores vendidos
    duplicados(ptrVendidos, numItens, total);

    // Ordena os produtos vendidos pelo valor vendido em ordem decrescente
    bbSort(ptrVendidos, numItens);

    printf(" +--------------------------------------------------------------------------------+\n");
    printf(" |                               CUPOM FISCAL                                     |\n");
    printf(" +--------------------------------------------------------------------------------+\n");
    printf(" |   Cod   | Nome do Item               | Valor Unitario | Quant. |    Subtotal   |\n");

    // Imprime os produtos vendidos no cupom fiscal
    for (int i = 0; i < numItens; i++) {
        if (ptrVendidos[i].quantidade > 0) {
            printf(" +--------------------------------------------------------------------------------+\n");
            printf(" |    %-4d | %-25s  |   R$ %-9.2f |   %-3d  |    R$ %-5.2f   |\n",
                ptrVendidos[i].codigo, ptrVendidos[i].nome, ptrVendidos[i].valor, ptrVendidos[i].quantidade, ptrVendidos[i].valorVendido);

            // Calcula o total vendido somando o valor vendido do produto atual
            total += ptrVendidos[i].valorVendido;
        }
    }

    printf(" +--------------------------------------------------------------------------------+\n");
    printf(" |                                                       | Total  |    R$ %-5.2f   |\n", total);
    printf(" +--------------------------------------------------------------------------------+\n");
}

void menu_pagamento(float total){

    int op;
    int erro_menu_pagamento = 0;

    // Exibe as op��es de pagamento dispon�veis
    printf("\n   A vista \n");
    printf(" +----------------------------------------------+\n");
    printf(" | Ate R$ 50,00 - 5 %% de desconto               |\n");
    printf(" +----------------------------------------------+\n");
    printf(" | Entre R$ 50,01 e R$ 99,99 - 10 %% de desconto |\n");
    printf(" +----------------------------------------------+\n");
    printf(" | Acima de R$ 100,00 - 18 %% de desconto        |\n");
    printf(" +----------------------------------------------+\n");
    printf("   A prazo \n");
    printf(" +----------------------------------------+\n");
    printf(" | Ate 3 parcelas - 5 %% de acrescimo      |\n");
    printf(" +----------------------------------------+\n");
    printf(" | Acima de 3 parcelas - 8 %% de acrescimo |\n");
    printf(" +----------------------------------------+\n");

    printf("\n Escolha a forma de pagamento:\n");
    printf("\n 1 - Pagamento a vista");
    printf("\n 2 - Pagamento a prazo\n");

    do {
        printf("\n Opcao: ");
        scanf("%d", &op);
        getchar();

        switch(op) {
            case 1:
                avista(&total);  // Chama a fun��o para pagamento � vista
                break;
            case 2:
                aprazo(&total);  // Chama a fun��o para pagamento a prazo
                break;
            default:
                printf("\n Opcao Invalida \n");
                erro_menu_pagamento = 1;  // Indica que houve um erro na escolha da op��o
                break;
        }
    } while(erro_menu_pagamento);

    menu_venda();  // Volta ao menu de vendas
}

void avista(float *total) {

    float desconto = 0.0, recebido = 0.0, troco = 0.0;
    char opc;

    // Verifica o valor do total e calcula o desconto com base nesse valor
    if (*total <= 50.00) {
        desconto = *total * 0.05;
    } else if (*total > 50.00 && *total < 100.00) {
        desconto = *total * 0.10;
    } else {
        desconto = *total * 0.18;
    }

    // Exibe o desconto aplicado e o total a ser pago
    printf("\n +--------------------------+\n");
    printf(" | Desconto:    R$ %-6.2f   | ", desconto);
    printf("\n +--------------------------+\n");
    printf(" | TOTAL:       R$ %-6.2f   | ", *total - desconto);
    printf("\n +--------------------------+\n");

    // Verifica se o cliente precisa de troco
    printf("\n Precisa de troco?(S/N): ");
    scanf(" %c", &opc);
    getchar();

    if (opc == 's' || opc == 'S') {

        do {
            // Solicita o valor recebido e calcula o troco
            printf("\n Digite o valor recebido: R$ ");
            scanf("%f", &recebido);
            getchar();

            troco = recebido - (*total - desconto);

            if (troco >= -0.04) {
                // Exibe o troco e a mensagem de venda finalizada
                printf("\n +---------------------+\n");
                printf(" |  TROCO:  R$ %-6.2f  |", troco);
                printf("\n +---------------------+\n");
                printf("\n\t\t Venda Finalizada!\n");
            } else {
                // Exibe a mensagem de valor insuficiente e a quantidade faltante
                printf("\n Valor insuficiente! Falta R$ %.2f \n", troco * -1);
            }
        } while (troco < -0.04);

    } else {
        printf("\n\t\t Venda Finalizada!\n");
    }
}

void aprazo(float *total) {
    int parcelas = 0;
    float acrescimo = 0.0;

    // Solicita o n�mero de parcelas ao cliente e valida o valor
    do {
        printf("\n Digite o numero de parcelas: ");
        scanf("%d", &parcelas);
        getchar();

        if (parcelas < 1) {
            printf("\n\tNumero de parcelas invalido, digite um valor igual ou acima de 1 parcela!\n");
        }
    } while (parcelas < 1);

    // Verifica o n�mero de parcelas e calcula o acr�scimo com base nesse n�mero
    if (parcelas <= 3) {
        acrescimo = *total * 0.05;
    } else {
        acrescimo = *total * 0.08;
    }

    // Exibe o acr�scimo, o total a ser pago e o valor das parcelas
    printf("\n +-------------------------+\n");
    printf(" | Acrescimo:   R$ %-6.2f  |", acrescimo);
    printf("\n +-------------------------+\n");
    printf(" | TOTAL:       R$ %-6.2f  |", *total + acrescimo);
    printf("\n +-------------------------+\n");
    printf(" |   Em %-2dx de R$ %-6.2f   |", parcelas, (*total + acrescimo) / parcelas);
    printf("\n +-------------------------+\n");

    printf("\n\t\t Venda Finalizada!\n");
}

void relatorio() {
    float totalVendido = 0.0;

    // Verifica se o estoque est� vazio ou se n�o h� nenhum produto cadastrado
    if (estoque == NULL || indiceG == 0) {
        printf("\n Nenhum Produto no estoque \n");
        return;
    }

    // Exibe o cabe�alho do relat�rio
    printf("\n +------------------------------------------------------------------------------------------+\n");
    printf(" |  cod  | Nome do Item              | Valor Unit. | Estoque | Qtd. Vendida | Total Vendido |\n");

    // Itera sobre o estoque para exibir os produtos vendidos
    for (int i = 0; i < indiceG; i++) {
        if (estoque[i].qtdVendida > 0) {
            // Exibe as informa��es do produto vendido
            printf(" +------------------------------------------------------------------------------------------+\n");
            printf(" |   %-4d| %-25s |   R$ %-6.2f |    %-3d  |      %-3d     |    R$ %-6.2f  |\n",
                   estoque[i].codigo, estoque[i].nome, estoque[i].valor, estoque[i].quantidade,
                   estoque[i].qtdVendida, estoque[i].valorVendido);

            // Calcula o total vendido somando o valor vendido do produto atual
            totalVendido += estoque[i].valorVendido;
        }
    }

    // Exibe o total vendido
    printf(" +------------------------------------------------------------------------------------------+\n");
    printf(" |                                                                        TOTAL: R$ %-6.2f  |\n", totalVendido);
    printf(" +------------------------------------------------------------------------------------------+\n");

    salvarRelatorioTXT(); // Chamada da fun��o 'salvarRelatorioTXT()' para salvar o relat�rio em um arquivo de texto
}

void salvarRelatorioTXT() {
    FILE *arquivo;

    // Abre o arquivo "relatorio.txt" para escrita

    arquivo = fopen("relatorio.txt", "w");

    fprintf(arquivo, " +----------------------------------------------------------------------------------------+\n");
    fprintf(arquivo, " | cod | Nome do Item              | Valor Unit. | Estoque | Qtd. Vendida | Total Vendido |\n");

    // Itera sobre o estoque para escrever as informa��es dos produtos vendidos no arquivo
    for (int i = 0; i < indiceG; i++) {
        if (estoque[i].qtdVendida > 0) {
            // Escreve as informa��es do produto vendido no arquivo
            fprintf(arquivo, " +----------------------------------------------------------------------------------------+\n");
            fprintf(arquivo, " |  %-3d| %-25s |   R$ %-6.2f |    %-3d  |      %-3d     |    R$ %-6.2f  |\n",
                   estoque[i].codigo, estoque[i].nome, estoque[i].valor, estoque[i].quantidade,
                   estoque[i].qtdVendida, estoque[i].valorVendido);
        }
    }
    fprintf(arquivo, " +----------------------------------------------------------------------------------------+\n");
    // Fecha o arquivo
    fclose(arquivo);
}
